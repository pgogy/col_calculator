=== Plugin Name ===
Contributors: pgogy
Tags: adjunct action, adjunct, pay, calculator
Requires at least: 3.0.0
Tested up to: 4.2.2
Stable tag: 0.2

Adjunct Action unites adjunct professors at campuses across the country to address the crisis in higher education and the troubling trend toward a marginalized teaching faculty that endangers our profession.

== Description ==

Adjunct Action unites adjunct professors at campuses across the country to address the crisis in higher education and the troubling trend toward a marginalized teaching faculty that endangers our profession.

This plugin - http://adjunctaction.org/adjunct-living-calculator/ - can be used on your site or in other locations to work out how well teaching faculty are paid where you live.

== Installation ==

This section describes how to install the plugin and get it working.

e.g.

1. Upload the contents of the zip (including the folder) to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Visit the settings page for the plugin - No other configuration is required.

== Changelog ==

Handling file saving issue

== Screenshots ==

== Frequently Asked Questions ==

We are a new plugin - so no questions so far.

== Upgrade Notice ==

None exist so far